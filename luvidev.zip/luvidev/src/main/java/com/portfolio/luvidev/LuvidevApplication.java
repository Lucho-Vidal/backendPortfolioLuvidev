package com.portfolio.luvidev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuvidevApplication {

	public static void main(String[] args) {
		SpringApplication.run(LuvidevApplication.class, args);
	}

}
