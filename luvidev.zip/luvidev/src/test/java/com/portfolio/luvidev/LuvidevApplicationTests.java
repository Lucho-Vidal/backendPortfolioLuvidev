package com.portfolio.luvidev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuvidevApplicationTests {

	@Test
	void contextLoads() {
	}

}
